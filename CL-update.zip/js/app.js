/* CL app shell + hash router */
(function () {
  const PRIMARY = new Set(["home", "books", "movies", "games", "more"]);

  const ROUTES = {
    home: { title: "Home", nav: "home", render: () => CL.sections.home.render },
    movies: { title: "Movies", nav: "movies", render: () => CL.sections.movies.render },
    games: { title: "Games", nav: "games", render: () => CL.sections.games.render },
    fun: { title: "8-Ball", nav: "more", render: () => CL.sections.fun.render },
    more: { title: "More", nav: "more", render: () => renderMore },
    notes: { title: "Notes", nav: "more", render: () => CL.sections.notes.render },
    books: { title: "Books", nav: "books", render: () => CL.sections.books.render },
    pigeon: { title: "Carrier Pigeon", nav: "more", render: () => CL.sections.pigeon.render },
    mail: { title: "Carrier Pigeon", nav: "more", render: () => CL.sections.pigeon.render },
    carrier: { title: "Carrier Pigeon", nav: "more", render: () => CL.sections.pigeon.render },
    timeline: { title: "Calendar", nav: "more", render: () => CL.sections.timeline.render },
    schedule: { title: "Calendar", nav: "more", render: () => CL.sections.timeline.render },
    calendar: { title: "Calendar", nav: "more", render: () => CL.sections.timeline.render },
    profile: { title: "Profile", nav: "more", render: () => CL.sections.profile.render },
    settings: { title: "Profile", nav: "more", render: () => CL.sections.profile.render }
  };

  function currentRoute() {
    const hash = (location.hash || "#home").replace(/^#/, "").split("?")[0].toLowerCase();
    // Legacy routes (CFB section removed)
    if (hash === "cfb" || hash === "football" || hash === "food" || hash === "news") return "home";
    if (hash === "cpa" || hash === "rankings") return "home";
    if (hash === "workout" || hash === "workouts") return "home";
    return ROUTES[hash] ? hash : "home";
  }

  function setActiveNav(routeKey) {
    const navKey = ROUTES[routeKey]?.nav || "home";
    document.querySelectorAll(".nav-item").forEach((el) => {
      el.classList.toggle("active", el.dataset.route === navKey);
    });
  }

  function refreshHeader() {
    const mark = document.getElementById("header-avatar");
    if (mark) {
      const p = CL.profile.get();
      if (p.avatar) {
        mark.innerHTML = `<img src="${p.avatar}" alt="" class="header-avatar-img" />`;
        mark.classList.add("has-photo");
      } else {
        mark.innerHTML = `<img src="icons/icon-96.png" alt="" class="header-avatar-img" />`;
        mark.classList.add("has-photo");
      }
    }
    if (CL.daycount && typeof CL.daycount.getCountdowns === "function") {
      const c = CL.daycount.getCountdowns();
      const annivEl = document.getElementById("header-daycount");
      const annivWrap = document.getElementById("hc-anniv");
      if (annivEl) {
        const compact = c.anniv.beforeStart
          ? "Soon"
          : "M" + c.anniv.months + " D" + c.anniv.days;
        const extra = c.anniv.beforeStart ? "" : " · " + c.anniv.elapsed + "d";
        annivEl.textContent = compact + extra;
        const long = CL.daycount.formatLong(c.anniv);
        if (annivWrap) {
          annivWrap.title = long;
          annivWrap.setAttribute("aria-label", long);
        }
      }
      const breakEl = document.getElementById("header-break");
      const breakWrap = document.getElementById("hc-break");
      if (breakEl) {
        breakEl.textContent = c.breakLabel;
        const bTitle =
          c.breakDays > 0
            ? c.breakDays + " days until break (Dec 19, 2026) · " + c.breakPctLabel + " of the way from Oct 20"
            : c.breakDays === 0
              ? "Break is today · Dec 19, 2026"
              : "Break date has passed";
        if (breakWrap) {
          breakWrap.title = bTitle;
          breakWrap.setAttribute("aria-label", bTitle);
          breakWrap.classList.toggle("is-soon", c.breakDays >= 0 && c.breakDays <= 30);
          breakWrap.classList.toggle("is-done", c.breakDays < 0);
        }
        const breakBar = document.getElementById("header-break-bar");
        const breakPctEl = document.getElementById("header-break-pct");
        if (breakBar) breakBar.style.width = c.breakPct + "%";
        if (breakPctEl) breakPctEl.textContent = c.breakPctLabel + " to break";
      }
      const ldEl = document.getElementById("header-ld");
      const ldWrap = document.getElementById("hc-ld");
      if (ldEl) {
        ldEl.textContent = c.ldLabel;
        const lTitle =
          c.ldDays > 0
            ? c.ldDays + " days until long distance is potentially over (Jul 25, 2027) · " + c.ldPctLabel + " from Apr 11"
            : c.ldDays === 0
              ? "Long distance is potentially over today · Jul 25, 2027"
              : "That date has passed";
        if (ldWrap) {
          ldWrap.title = lTitle;
          ldWrap.setAttribute("aria-label", lTitle);
          ldWrap.classList.toggle("is-soon", c.ldDays >= 0 && c.ldDays <= 30);
          ldWrap.classList.toggle("is-done", c.ldDays < 0);
        }
        const ldBar = document.getElementById("header-ld-bar");
        const ldPctEl = document.getElementById("header-ld-pct");
        if (ldBar) ldBar.style.width = c.ldPct + "%";
        if (ldPctEl) ldPctEl.textContent = c.ldPctLabel + " to Jul 25";
      }
    }
    if (CL.pigeon && typeof CL.pigeon.updateBadges === "function") {
      CL.pigeon.updateBadges();
    }
  }

  CL.refreshHeader = refreshHeader;

  function renderMore(root) {
    const pigeonUnread = CL.pigeon && typeof CL.pigeon.unreadCount === "function" ? CL.pigeon.unreadCount() : 0;
    root.innerHTML = `
      <section class="page">
        <h1 class="page-title">More</h1>
        <p class="page-sub">Everything else for ${CL.escapeHtml(CL.profile.coupleLabel())}</p>
        <div class="more-grid">
          <button type="button" class="more-card" data-go="profile">
            <span class="emoji">💕</span>
            <strong>Profile & Settings</strong>
            <p>Names & couple group</p>
            <span class="badge">Open</span>
          </button>
          <button type="button" class="more-card" data-go="notes">
            <span class="emoji">📝</span>
            <strong>Notes</strong>
            <p>Shared scratch paper · rich text</p>
            <span class="badge">Open</span>
          </button>
          <button type="button" class="more-card" data-go="books">
            <span class="emoji">📚</span>
            <strong>Book Club</strong>
            <p>Shelves, reviews & recs</p>
            <span class="badge">Open</span>
          </button>
          <button type="button" class="more-card" data-go="timeline">
            <span class="emoji">📅</span>
            <strong>Calendar</strong>
            <p>Cole, Lauren &amp; together</p>
            <span class="badge">Open</span>
          </button>
          <button type="button" class="more-card" data-go="pigeon">
            <span class="emoji">🕊️</span>
            <strong>Carrier Pigeon</strong>
            <p>Farm post · letters in flight</p>
            <span class="badge">${pigeonUnread ? pigeonUnread + " new" : "Open"}</span>
          </button>
          <button type="button" class="more-card" data-go="games">
            <span class="emoji">🎮</span>
            <strong>Games</strong>
            <p>Golf, darts, spades, gin</p>
            <span class="badge">Open</span>
          </button>
          <button type="button" class="more-card" data-go="fun">
            <span class="emoji">🎱</span>
            <strong>8-Ball</strong>
            <p>Two options. One survives.</p>
            <span class="badge">Open</span>
          </button>
        </div>
        <div class="card" style="margin-top:16px">
          <div class="card-title">About CL</div>
          <p class="card-meta" style="margin-top:6px">
            Your private couple app. Data lives on this device and can sync via a Couple Group
            (Firebase). Set names under Profile and keep movies, games, books, notes, Calendar &amp; Carrier Pigeon.
          </p>
        </div>
      </section>
    `;

    root.querySelectorAll("[data-go]").forEach((btn) => {
      btn.addEventListener("click", () => {
        location.hash = btn.dataset.go;
      });
    });
  }

  function route() {
    const key = currentRoute();
    const def = ROUTES[key];
    const main = document.getElementById("main");
    if (!main || !def) return;

    // Normalize legacy hashes
    const rawHash = (location.hash || "").replace(/^#/, "").split("?")[0].toLowerCase();
    if (rawHash === "cfb" || rawHash === "football" || rawHash === "food" || rawHash === "news") {
      location.replace("#home");
      return;
    }
    if (rawHash === "workout" || rawHash === "workouts") {
      location.replace("#home");
      return;
    }

    document.title = `CL · ${def.title}`;
    setActiveNav(key);
    refreshHeader();
    main.innerHTML = "";
    main.classList.remove("page-enter");
    void main.offsetWidth;
    main.classList.add("page-enter");
    window.scrollTo({ top: 0, behavior: "smooth" });

    const renderFn = def.render();
    if (typeof renderFn === "function") renderFn(main);
  }

  function init() {
    if (!location.hash || location.hash === "#") {
      location.replace("#home");
    }

    window.addEventListener("hashchange", route);
    document.getElementById("btn-home")?.addEventListener("click", () => {
      location.hash = "#home";
    });

    document.querySelectorAll(".nav-item").forEach((el) => {
      el.addEventListener("click", () => {
        sessionStorage.setItem("cl_seen_home", "1");
      });
    });

    try {
      localStorage.removeItem("cl_workouts");
    } catch (_) {}
    const purgeWorkoutsRemote = () => {
      if (CL.storage.get("_purged_workouts_v1", false)) return;
      if (!(CL.sync && typeof CL.sync.isJoined === "function" && CL.sync.isJoined())) return;
      CL.storage.set("_purged_workouts_v1", true, { skipSync: true });
      CL.sync.pushKey("workouts", null);
    };
    purgeWorkoutsRemote();
    window.addEventListener("cl-sync-status", purgeWorkoutsRemote);

    refreshHeader();
    route();

    if (CL.pigeon && typeof CL.pigeon.startBackground === "function") {
      CL.pigeon.startBackground();
    }

    let syncRefreshTimer = null;
    window.addEventListener("cl-sync-update", (e) => {
      const k = e.detail && e.detail.key;
      if (!k) return;
      clearTimeout(syncRefreshTimer);
      syncRefreshTimer = setTimeout(() => {
        const ae = document.activeElement;
        const tag = (ae && ae.tagName) || "";
        if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
        if (ae && ae.isContentEditable) return;
        route();
      }, 400);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
